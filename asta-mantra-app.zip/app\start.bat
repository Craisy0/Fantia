@echo off
cd /d "%~dp0"
echo Avvio server Asta Mantra su http://localhost:8765 ...
"C:\Python313\python.exe" server.py 8765
pause
